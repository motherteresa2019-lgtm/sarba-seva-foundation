SARBA SEVA FOUNDATION WEBSITE

Files:
- index.html: complete responsive website.

BEFORE PUBLISHING:
1. Open index.html in a browser to preview.
2. Replace the bracketed address, phone and email placeholders with official details.
3. Replace illustrative stock photographs with genuine activity photographs where possible.
4. The enquiry form is a demonstration only. It does not send or store messages.

FREE PUBLISHING WITH GITHUB PAGES:
1. Create/sign in to a free GitHub account at https://github.com/
2. Create a new public repository named sarba-seva-foundation
3. Upload index.html to the repository root (top level).
4. Open repository Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select branch main and folder /(root), then Save.
7. Wait a few minutes. GitHub will show your public website address in Settings > Pages.

Your free address will look like:
https://YOUR-USERNAME.github.io/sarba-seva-foundation/

No paid domain is required. GitHub Pages may take a few minutes to publish.
